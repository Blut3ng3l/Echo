import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BUDAPEST, SEEDS, TYPES, TYPE, distanceMeters } from './src/data';

const COLORS = { bg: '#0D1020', panel: '#191E32', panel2: '#222940', outline: '#373B57', white: '#F4F0FF', muted: '#A5ADC5', purple: '#A98AFF', cyan: '#5ADDE2', error: '#FF9DAD' };
const STORE = 'echo-prototype-stories-v1';
const DISCOVERED_STORE = 'echo-prototype-discovered-v1';
const RADIUS = 150;
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

function P({ children, style, ...props }) { return <Text {...props} style={[styles.body, style]}>{children}</Text>; }
function Button({ children, onPress, secondary = false, disabled = false, style }) {
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, secondary && styles.buttonSecondary, disabled && { opacity: 0.45 }, pressed && { opacity: 0.75 }, style]}><Text style={[styles.buttonText, secondary && { color: COLORS.white }]}>{children}</Text></Pressable>;
}
function Tag({ type }) { const t = TYPE(type); return <View style={[styles.tag, { backgroundColor: `${t.color}22` }]}><P style={{ color: t.color, fontSize: 12, fontWeight: '800' }}>{t.icon}  {t.label}</P></View>; }
function Heading({ eyebrow, title, detail }) { return <View style={{ marginBottom: 17 }}><P style={styles.eyebrow}>{eyebrow}</P><P style={styles.heading}>{title}</P>{detail ? <P style={styles.muted}>{detail}</P> : null}</View>; }

export default function App() {
  const [tab, setTab] = useState('map');
  const [stories, setStories] = useState(SEEDS);
  const [discovered, setDiscovered] = useState([]);
  const [ready, setReady] = useState(false);
  const [location, setLocation] = useState(null);
  const [gpsStatus, setGpsStatus] = useState('A helyzet még nincs megadva.');
  const [selected, setSelected] = useState(null);
  const [demoMode, setDemoMode] = useState(true);
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [draftType, setDraftType] = useState('memory');
  const [draftTitle, setDraftTitle] = useState('');
  const [draftText, setDraftText] = useState('');
  const [draftPlace, setDraftPlace] = useState('');
  const [draftPoint, setDraftPoint] = useState(null);
  const [placement, setPlacement] = useState(false);
  const mapRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const [saved, unlocked] = await Promise.all([AsyncStorage.getItem(STORE), AsyncStorage.getItem(DISCOVERED_STORE)]);
        if (saved) {
          const list = JSON.parse(saved);
          if (Array.isArray(list)) setStories([...SEEDS, ...list.filter((x) => x && typeof x.id === 'string' && !x.demo)]);
        }
        if (unlocked) {
          const ids = JSON.parse(unlocked);
          if (Array.isArray(ids)) setDiscovered(ids);
        }
      } catch { Alert.alert('Tárolási hiba', 'A helyi emlékek betöltése nem sikerült.'); }
      finally { setReady(true); }
    })();
  }, []);

  const requestLocation = useCallback(async () => {
    try {
      setGpsStatus('Helyzet lekérése…');
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== 'granted') { setGpsStatus('A helymeghatározás nincs engedélyezve. A demó enélkül is használható.'); return null; }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const pt = { latitude: position.coords.latitude, longitude: position.coords.longitude };
      setLocation(pt);
      setGpsStatus('Helyzet elérhető.');
      return pt;
    } catch { setGpsStatus('Nem sikerült meghatározni a helyzetet.'); return null; }
  }, []);

  const recenter = async () => {
    const pt = await requestLocation();
    if (pt) mapRef.current?.animateToRegion({ ...pt, latitudeDelta: 0.025, longitudeDelta: 0.025 }, 500);
  };
  const filtered = stories.filter(s => (category === 'all' || category === s.type) && `${s.title} ${s.locationName} ${s.text}`.toLocaleLowerCase('hu').includes(search.toLocaleLowerCase('hu')));
  const onChoose = (s) => { if (!placement) setSelected(s); };
  const isUnlocked = (s) => discovered.includes(s.id);
  const canUnlock = (s) => !!(demoMode && s.demo) || (!!location && distanceMeters(location, s) <= RADIUS);
  const unlock = async (s) => {
    if (!canUnlock(s)) {
      Alert.alert('A helyszín túl messze van', `A feloldáshoz a pont ${RADIUS} méteres körzetében kell lenned. Kapcsold be a helyzetmeghatározást. A demó mód csak a mintatörténeteket nyitja meg.`);
      return;
    }
    const next = [...new Set([...discovered, s.id])];
    try { await AsyncStorage.setItem(DISCOVERED_STORE, JSON.stringify(next)); setDiscovered(next); }
    catch { Alert.alert('Mentési hiba', 'A feloldás mentése nem sikerült.'); }
  };
  const saveStory = async () => {
    const title = draftTitle.trim(); const text = draftText.trim();
    if (title.length < 3 || text.length < 10) { Alert.alert('Hiányos történet', 'A cím legalább 3, a történet legalább 10 karakter legyen.'); return; }
    if (!draftPoint) { Alert.alert('Hiányzik a hely', 'Válassz egy pontot a térképen, vagy add meg a jelenlegi helyzetedet.'); return; }
    const s = { id: uid(), type: draftType, title: title.slice(0, 80), text: text.slice(0, 2000), locationName: draftPlace.trim().slice(0, 80) || 'Saját helyszín', ...draftPoint, createdAt: new Date().toISOString(), demo: false };
    const saved = [...stories.filter(x => !x.demo), s];
    try {
      await AsyncStorage.setItem(STORE, JSON.stringify(saved));
      setStories([...SEEDS, ...saved]);
      setDraftTitle(''); setDraftText(''); setDraftPlace(''); setDraftPoint(null); setDraftType('memory');
      setTab('map'); setSelected(s); mapRef.current?.animateToRegion({ ...draftPoint, latitudeDelta: 0.02, longitudeDelta: 0.02 }, 500);
      Alert.alert('Visszhang elhelyezve ✦', 'Az emlék a készülékeden tárolódik. Mások egyelőre nem látják.');
    } catch { Alert.alert('Mentési hiba', 'Az emlék mentése nem sikerült. Próbáld újra.'); }
  };
  const removeStory = (s) => {
    Alert.alert('Emlék törlése', `Biztosan törlöd: „${s.title}”?`, [
      { text: 'Mégse', style: 'cancel' },
      { text: 'Törlés', style: 'destructive', onPress: async () => {
        const remaining = stories.filter(x => !x.demo && x.id !== s.id);
        try { await AsyncStorage.setItem(STORE, JSON.stringify(remaining)); setStories([...SEEDS, ...remaining]); setSelected(null); }
        catch { Alert.alert('Hiba', 'Nem sikerült törölni.'); }
      } },
    ]);
  };
  const placeOnMap = () => { setPlacement(true); setTab('map'); setSelected(null); };
  const useCurrentForDraft = async () => { const pt = await requestLocation(); if (pt) { setDraftPoint(pt); Alert.alert('Hely kiválasztva', 'A jelenlegi helyzetedet társítottuk az új emlékhez.'); } };

  if (!ready) return <SafeAreaView style={[styles.root, { justifyContent: 'center', alignItems: 'center' }]}><ActivityIndicator color={COLORS.purple} size="large"/><P style={styles.muted}>Az ECHO ébredezik…</P></SafeAreaView>;
  return <SafeAreaView style={styles.root}>
    <StatusBar barStyle="light-content" backgroundColor={COLORS.bg}/>
    <View style={styles.topBar}><View><P style={styles.logo}>ECHO <Text style={{ color: COLORS.cyan }}>✦</Text></P><P style={styles.subtitle}>A világ emlékezik.</P></View><View style={styles.prototype}><P style={{ color: COLORS.purple, fontSize: 10, fontWeight: '800' }}>PROTOTÍPUS</P></View></View>
    <View style={{ flex: 1 }}>
      <View style={[styles.tabContent, { display: tab === 'map' ? 'flex' : 'none' }]}>
        <MapView ref={mapRef} provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined} style={StyleSheet.absoluteFillObject} initialRegion={BUDAPEST} customMapStyle={darkMapStyle} showsUserLocation={!!location} onPress={(e) => {
          if (placement) { const pt = e.nativeEvent.coordinate; setDraftPoint(pt); setPlacement(false); setTab('create'); }
        }}>
          {filtered.map(s => <Marker key={s.id} coordinate={{ latitude: s.latitude, longitude: s.longitude }} onPress={() => onChoose(s)} tracksViewChanges={false}>
            <View style={[styles.marker, { borderColor: TYPE(s.type).color, backgroundColor: COLORS.panel }]}><Text style={{ color: TYPE(s.type).color, fontSize: 19 }}>{TYPE(s.type).icon}</Text></View>
          </Marker>)}
        </MapView>
        <View style={styles.mapOverlay} pointerEvents="box-none">
          <View style={styles.mapHeader}><P style={styles.mapEyebrow}>{placement ? 'ÚJ EMLÉK HELYSZÍNE' : 'FEDEZD FEL'}</P><P style={styles.mapTitle}>{placement ? 'Érintsd meg a térképet' : 'A láthatatlan történeteket'}</P><P style={{ color: COLORS.muted, fontSize: 12 }}>{placement ? 'A kiválasztott pontra kerül az új emlék.' : `${filtered.length} visszhang a térképen · Budapest bemutató`}</P></View>
          <View style={{ flex: 1 }}/>
          <View style={{ alignItems: 'flex-end', marginBottom: 12 }}><Button secondary onPress={recenter} style={{ minWidth: 112 }}>◎ Helyzetem</Button></View>
          <View style={styles.mapFooter}>
            <P style={{ color: COLORS.muted, fontSize: 12 }}>{placement ? 'Helyválasztás folyamatban' : gpsStatus}</P>
            {placement ? <Button secondary onPress={() => { setPlacement(false); setTab('create'); }}>Mégse</Button> : <Button onPress={() => setTab('explore')}>Visszhangok böngészése  →</Button>}
          </View>
        </View>
      </View>
      {tab === 'explore' && <ScrollView contentContainerStyle={styles.screen} keyboardShouldPersistTaps="handled">
        <Heading eyebrow="DISCOVER / 01" title="Fedezd fel" detail="A város történetei rád várnak."/>
        <TextInput style={styles.input} value={search} onChangeText={setSearch} placeholder="Keress címre, helyszínre…" placeholderTextColor="#7F87A1"/>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, marginBottom: 16 }}>
          {[{ id: 'all', label: 'Mind' }, ...TYPES].map(x => <Pressable key={x.id} onPress={() => setCategory(x.id)} style={[styles.filter, category === x.id && styles.filterActive]}><P style={{ color: category === x.id ? COLORS.bg : COLORS.white, fontWeight: '700', fontSize: 13 }}>{x.label}</P></Pressable>)}
        </ScrollView>
        {filtered.length ? filtered.map(s => <Pressable key={s.id} onPress={() => setSelected(s)} style={styles.storyCard}><View style={styles.cardRow}><Tag type={s.type}/>{s.demo ? <P style={styles.micro}>DEMÓ</P> : <P style={styles.micro}>SAJÁT</P>}</View><P style={styles.cardTitle}>{s.title}</P><P style={styles.muted} numberOfLines={2}>{isUnlocked(s) ? s.text : 'Egy emlék vár, hogy felfedezd. A történet a helyszínen nyitható meg.'}</P><P style={styles.cardFoot}>⌖ {s.locationName}   ·   {isUnlocked(s) ? 'Feloldva ✓' : 'Zárolva ◇'}</P></Pressable>) : <P style={styles.muted}>Nincs találat. Próbálj másik keresést!</P>}
      </ScrollView>}
      {tab === 'create' && <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}><ScrollView contentContainerStyle={styles.screen} keyboardShouldPersistTaps="handled">
        <Heading eyebrow="CREATE / 02" title="Hagyj egy visszhangot" detail="Őrizz meg egy pillanatot egy helyhez kötve."/>
        <P style={styles.fieldLabel}>MILYEN TÖRTÉNET?</P><View style={styles.typeGrid}>{TYPES.map(t => <Pressable key={t.id} onPress={() => setDraftType(t.id)} style={[styles.typeOption, draftType === t.id && { borderColor: t.color, backgroundColor: `${t.color}1B` }]}><P style={{ color: t.color, fontSize: 21 }}>{t.icon}</P><P style={{ fontSize: 12, color: COLORS.white }}>{t.label}</P></Pressable>)}</View>
        <P style={styles.fieldLabel}>CÍM</P><TextInput maxLength={80} style={styles.input} value={draftTitle} onChangeText={setDraftTitle} placeholder="Adj címet az emléknek…" placeholderTextColor="#7F87A1"/>
        <P style={styles.fieldLabel}>TÖRTÉNET</P><TextInput maxLength={2000} multiline textAlignVertical="top" style={[styles.input, { minHeight: 150 }]} value={draftText} onChangeText={setDraftText} placeholder="Mi történt itt? Mit szeretnél megőrizni?" placeholderTextColor="#7F87A1"/>
        <P style={styles.fieldLabel}>HELYSZÍN NEVE (NEM KÖTELEZŐ)</P><TextInput maxLength={80} style={styles.input} value={draftPlace} onChangeText={setDraftPlace} placeholder="Pl. Kedvenc padom" placeholderTextColor="#7F87A1"/>
        <P style={styles.fieldLabel}>HELY KIVÁLASZTÁSA</P><View style={styles.row}><Button secondary style={{ flex: 1 }} onPress={placeOnMap}>⌖ Térképen</Button><Button secondary style={{ flex: 1 }} onPress={useCurrentForDraft}>◎ Itt vagyok</Button></View>
        <P style={[styles.muted, { marginVertical: 12, fontSize: 12 }]}>{draftPoint ? `✓ Pont kiválasztva: ${draftPoint.latitude.toFixed(5)}, ${draftPoint.longitude.toFixed(5)}` : 'Még nem választottál helyszínt.'}</P>
        <View style={styles.notice}><P style={{ color: COLORS.cyan, fontSize: 12 }}>✦ A prototípusban az emlékek csak ezen a készüléken láthatók. Ne jelölj meg mások privát lakcímét.</P></View>
        <Button onPress={saveStory} style={{ marginTop: 16 }}>✦ Visszhang elhelyezése</Button>
      </ScrollView></KeyboardAvoidingView>}
      {tab === 'saved' && <ScrollView contentContainerStyle={styles.screen}>
        <Heading eyebrow="COLLECTION / 03" title="Gyűjteményem" detail="A felfedezett történetek és saját emlékek."/>
        <View style={styles.statRow}><View style={styles.stat}><P style={styles.statNumber}>{discovered.length}</P><P style={styles.muted}>Felfedezve</P></View><View style={styles.stat}><P style={styles.statNumber}>{stories.filter(x => !x.demo).length}</P><P style={styles.muted}>Saját emlék</P></View></View>
        <P style={styles.fieldLabel}>FELFEDEZETT VISSZHANGOK</P>
        {stories.filter(x => discovered.includes(x.id)).map(s => <Pressable key={s.id} style={styles.storyCard} onPress={() => setSelected(s)}><Tag type={s.type}/><P style={styles.cardTitle}>{s.title}</P><P style={styles.cardFoot}>⌖ {s.locationName}</P></Pressable>)}
        {!discovered.length && <P style={[styles.muted, { marginBottom: 20 }]}>Még nem oldottál fel történetet.</P>}
        <P style={styles.fieldLabel}>SAJÁT EMLÉKEIM</P>
        {stories.filter(x => !x.demo).map(s => <Pressable key={s.id} style={styles.storyCard} onPress={() => setSelected(s)}><Tag type={s.type}/><P style={styles.cardTitle}>{s.title}</P><P style={styles.cardFoot}>⌖ {s.locationName}</P></Pressable>)}
        {!stories.some(x => !x.demo) && <P style={styles.muted}>Az első emlékedet a ✦ gombbal hozhatod létre.</P>}
        <View style={[styles.notice, { marginTop: 26 }]}><P style={styles.fieldLabel}>BEMUTATÓ ÜZEMMÓD</P><View style={styles.row}><P style={[styles.muted, { flex: 1, fontSize: 12 }]}>A 3 mintatörténet GPS nélkül is feloldható. Saját emlékekhez valódi közelség szükséges.</P><Switch value={demoMode} onValueChange={setDemoMode} trackColor={{ false: COLORS.outline, true: COLORS.purple }}/></View></View>
      </ScrollView>}
    </View>
    <View style={styles.nav}>
      {[['map', '◎', 'Térkép'], ['explore', '◇', 'Felfedezés'], ['create', '✦', 'Új emlék'], ['saved', '♡', 'Gyűjtemény']].map(([id, icon, label]) => <Pressable key={id} onPress={() => { setPlacement(false); setTab(id); }} style={styles.navItem}><P style={{ color: tab === id ? COLORS.purple : COLORS.muted, fontSize: 22, fontWeight: '600' }}>{icon}</P><P style={{ color: tab === id ? COLORS.white : COLORS.muted, fontSize: 10, fontWeight: tab === id ? '800' : '500' }}>{label}</P></Pressable>)}
    </View>
    <Modal visible={!!selected} transparent animationType="slide" onRequestClose={() => setSelected(null)}>
      <View style={styles.modalBackdrop}><View style={styles.modalSheet}>
        {selected && <><View style={styles.cardRow}><Tag type={selected.type}/><Pressable onPress={() => setSelected(null)} hitSlop={12}><P style={{ fontSize: 24, color: COLORS.muted }}>×</P></Pressable></View>
          <P style={[styles.heading, { marginTop: 14 }]}>{selected.title}</P><P style={styles.cardFoot}>⌖ {selected.locationName}</P>
          {isUnlocked(selected) || (!selected.demo && canUnlock(selected)) ? <View style={styles.readable}><P style={{ lineHeight: 26, fontSize: 16 }}>{selected.text}</P></View> : <View style={styles.locked}><P style={{ fontSize: 29, color: COLORS.purple, textAlign: 'center' }}>◇</P><P style={{ textAlign: 'center', fontWeight: '700' }}>Ez a visszhang még alszik.</P><P style={[styles.muted, { textAlign: 'center', marginTop: 8 }]}>Keresd fel a helyszínt, hogy megismerhesd a történetét.</P></View>}
          {!isUnlocked(selected) && <Button onPress={() => unlock(selected)}>{canUnlock(selected) ? '✦ Visszhang feloldása' : '◎ Megpróbálom feloldani'}</Button>}
          {isUnlocked(selected) && <P style={{ color: COLORS.cyan, marginTop: 12, textAlign: 'center', fontSize: 12 }}>✓ Feloldva · Elmentve a gyűjteményedbe</P>}
          {!selected.demo && <Button secondary onPress={() => removeStory(selected)} style={{ marginTop: 12 }}>Saját emlék törlése</Button>}
          {selected.demo && <P style={[styles.micro, { textAlign: 'center', marginTop: 12 }]}>FIKTÍV MINTATÖRTÉNET</P>}
        </>}
      </View></View>
    </Modal>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg, paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) : 0 },
  body: { color: COLORS.white, fontSize: 14 }, muted: { color: COLORS.muted, fontSize: 13, lineHeight: 20 },
  topBar: { height: 70, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 22, borderBottomColor: COLORS.outline, borderBottomWidth: 1 },
  logo: { color: COLORS.white, fontSize: 26, fontWeight: '900', letterSpacing: 4 }, subtitle: { color: COLORS.muted, fontSize: 11, letterSpacing: 1 }, prototype: { borderColor: COLORS.outline, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  tabContent: { flex: 1 }, screen: { padding: 22, paddingBottom: 35 }, eyebrow: { fontSize: 11, color: COLORS.purple, fontWeight: '800', letterSpacing: 2, marginBottom: 8 }, heading: { fontSize: 27, color: COLORS.white, fontWeight: '800', letterSpacing: -0.5, marginBottom: 5 },
  button: { backgroundColor: COLORS.purple, paddingVertical: 14, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center', borderRadius: 13 }, buttonSecondary: { backgroundColor: COLORS.panel2, borderWidth: 1, borderColor: COLORS.outline }, buttonText: { color: COLORS.bg, fontWeight: '900', fontSize: 13, textAlign: 'center' },
  nav: { minHeight: 67, backgroundColor: COLORS.bg, borderTopColor: COLORS.outline, borderTopWidth: 1, flexDirection: 'row', paddingBottom: 4 }, navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4 },
  marker: { width: 39, height: 39, borderRadius: 22, borderWidth: 2, justifyContent: 'center', alignItems: 'center' }, mapOverlay: { ...StyleSheet.absoluteFillObject, padding: 15 }, mapHeader: { backgroundColor: '#13182BED', borderRadius: 17, padding: 16, borderWidth: 1, borderColor: COLORS.outline }, mapEyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 2, color: COLORS.cyan }, mapTitle: { fontSize: 18, fontWeight: '800', color: COLORS.white, marginVertical: 5 }, mapFooter: { backgroundColor: COLORS.bg, borderRadius: 17, padding: 13, gap: 10 },
  input: { backgroundColor: COLORS.panel, borderWidth: 1, borderColor: COLORS.outline, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, marginBottom: 17, color: COLORS.white, fontSize: 15 }, fieldLabel: { color: COLORS.muted, fontSize: 11, letterSpacing: 1.3, fontWeight: '800', marginBottom: 10 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 }, typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 22 }, typeOption: { width: '48%', borderWidth: 1, borderColor: COLORS.outline, padding: 13, backgroundColor: COLORS.panel, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  filter: { paddingHorizontal: 15, paddingVertical: 10, backgroundColor: COLORS.panel, borderRadius: 22, marginRight: 8 }, filterActive: { backgroundColor: COLORS.purple }, storyCard: { padding: 18, marginBottom: 13, borderWidth: 1, borderColor: COLORS.outline, borderRadius: 17, backgroundColor: COLORS.panel, gap: 10 }, cardRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, cardTitle: { fontSize: 19, fontWeight: '800' }, cardFoot: { color: COLORS.cyan, fontSize: 12, marginTop: 4 }, tag: { alignSelf: 'flex-start', paddingVertical: 6, paddingHorizontal: 10, borderRadius: 14 }, micro: { color: COLORS.muted, fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  notice: { borderWidth: 1, borderColor: '#2D5A68', backgroundColor: '#142936', borderRadius: 13, padding: 13 }, statRow: { flexDirection: 'row', gap: 12, marginBottom: 25 }, stat: { flex: 1, backgroundColor: COLORS.panel, borderRadius: 15, padding: 20, borderWidth: 1, borderColor: COLORS.outline }, statNumber: { fontSize: 32, fontWeight: '900', color: COLORS.purple, marginBottom: 4 },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: '#050713C5' }, modalSheet: { backgroundColor: COLORS.panel, padding: 24, paddingBottom: 35, borderTopLeftRadius: 28, borderTopRightRadius: 28, borderColor: COLORS.outline, borderWidth: 1, maxHeight: '85%' }, readable: { backgroundColor: COLORS.panel2, padding: 18, borderRadius: 15, marginTop: 18, marginBottom: 17 }, locked: { backgroundColor: COLORS.panel2, padding: 30, borderRadius: 15, marginTop: 18, marginBottom: 17 },
});

const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#1c2338' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#858ca4' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#161b2a' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#343c55' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#122d46' }] },
  { featureType: 'poi', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', stylers: [{ visibility: 'off' }] },
];
