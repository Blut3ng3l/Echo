# ECHO – A világ emlékezik ✦

**Első, helyben futó Android MVP/prototípus** React Native + Expo SDK 58 alapokon.

## Mit tud?
- Sötét, lila-neonkék, magyar nyelvű felület, 4 képernyő.
- Google Maps térkép Androidon, három **kitalált** budapesti mintatörténettel.
- Emlék keresése és típus szerinti szűrése.
- Új szöveges emlék létrehozása, koordináta választása a térképen vagy a saját helyzet alapján.
- Saját emlékek tartós **helyi** mentése, törlése.
- Feloldás a pont **150 méteres** körzetében, engedélyezett helymeghatározással; mintatörténetek feloldhatók demó módban is.
- Gyűjtemény felfedezett és saját emlékekkel.

## Indítás Androidon
1. Telepítsd a Node.js 22.13 vagy frissebb verzióját a számítógépedre.
2. Csomagold ki az ECHO-Expo.zip fájlt, és nyiss terminált az `ECHO-Expo` mappában.
3. Futtasd:
   ```bash
   npm install
   npx expo install --fix
   npx expo start
   ```
4. Telepítsd a **Expo Go** alkalmazást Androidra a Google Play áruházból.
5. Az Expo által megjelenített QR-kódot olvasd be Expo Go-val. A telefon és a számítógép legyen azonos Wi-Fi hálózaton. Más hálózat esetén próbáld: `npx expo start --tunnel`.
6. Kattints a térképes jelölőkre, vagy a **Felfedezés** lapra. A **Gyűjtemény** oldalon a demó mód be van kapcsolva.

## Fontos korlátok
- Ez **forráskód**, nem kész APK és nem Google Playre feltölthető build. Nincs futtatási/telefonos teszt ebben a csomagban.
- Nincs backend, regisztráció, szinkron vagy több felhasználó: amit létrehozol, csak a saját telefonodon látszik.
- A szöveges emlékek *titkosítatlan AsyncStorage*-ban tárolódnak: bizalmas adatot ne írj bele.
- A 150 méteres GPS-feloldás prototípus-szintű; a telefon helyzetadata manipulálható. Éles alkalmazáshoz szerveroldali ellenőrzés, tartalommoderáció, adatvédelmi szabályzat és jelentés funkció kell.
- Fotó, hang, időkapszula-időzítés és valóban összekapcsolt ösvények a következő verzió feladatai. A típusválasztó már tartalmazza ezeket az előkészített kategóriákat.
- Valódi Android APK/AAB buildhez Expo EAS Build és konfiguráció szükséges, valamint a Google Maps API-kulcs beállítása a standalone Android buildhez.

## Fájlok
- `App.js` — teljes felület és alkalmazáslogika.
- `src/data.js` — típusok, demó tartalom, földrajzi távolságfüggvény.
- `app.json` — Expo/Android beállítások.
- `package.json` — projektfüggőségek.

Fejlesztési következő mérföldkő: Supabase/Firebase háttér, hitelesítés, közösségi emlékek, moderáció, biztonságos helymegosztás.
