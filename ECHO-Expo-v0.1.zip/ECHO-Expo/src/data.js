export const BUDAPEST = { latitude: 47.4979, longitude: 19.0402, latitudeDelta: 0.065, longitudeDelta: 0.065 };
export const TYPES = [
  { id: 'memory', label: 'Emlék', icon: '♡', color: '#FF87B5' },
  { id: 'secret', label: 'Titok', icon: '☾', color: '#BB9BFF' },
  { id: 'trail', label: 'Ösvény', icon: '✧', color: '#5ADDE2' },
  { id: 'capsule', label: 'Időkapszula', icon: '◷', color: '#F7C77D' },
];
export const TYPE = (id) => TYPES.find((t) => t.id === id) || TYPES[0];
// Kitalált, bemutató tartalom. Egyik történet sem valódi személy vallomása.
export const SEEDS = [
  { id: 'demo-1', type: 'memory', title: 'Az utolsó találkozás', text: 'Itt ültünk a Duna mellett. Azt mondtad, vannak pillanatok, amelyeket még az idő sem vehet el tőlünk. Most már értem, mire gondoltál.', latitude: 47.5182, longitude: 19.0469, locationName: 'Margitsziget', createdAt: '2026-11-01T12:00:00.000Z', demo: true },
  { id: 'demo-2', type: 'secret', title: 'A kimondatlan szó', text: 'Minden nap ugyanazon az úton mentünk haza. Sosem mondtam el, hogy nem a rövidebb út miatt választottam. Hanem miattad.', latitude: 47.5020, longitude: 19.0342, locationName: 'Budai Vár', createdAt: '2026-11-02T12:00:00.000Z', demo: true },
  { id: 'demo-3', type: 'trail', title: 'A hetedik harang', text: 'Az órásmester hét üzenetet hagyott maga után. Az első itt van. A második ott vár, ahol a város két partja találkozik. (Fiktív nyomozás, első fejezet.)', latitude: 47.4981, longitude: 19.0493, locationName: 'Belváros', createdAt: '2026-11-03T12:00:00.000Z', demo: true },
];
export function distanceMeters(a, b) {
  const rad = Math.PI / 180;
  const lat1 = a.latitude * rad;
  const lat2 = b.latitude * rad;
  const dlat = (b.latitude - a.latitude) * rad;
  const dlon = (b.longitude - a.longitude) * rad;
  const v = Math.sin(dlat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dlon / 2) ** 2;
  return Math.round(6371000 * 2 * Math.atan2(Math.sqrt(v), Math.sqrt(1 - v)));
}
